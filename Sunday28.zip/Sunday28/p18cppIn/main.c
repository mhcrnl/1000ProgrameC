#include <stdio.h>
#include <stdlib.h>
/** Negatia negatiei j = !!i ;*/
int main()
{
    printf("Hello world!\n");
    int i=1, j;
    j=!!i;
    printf("%d", j);
    return 0;
}
