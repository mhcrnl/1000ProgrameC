#include <stdio.h>
#include <stdlib.h>

int main()
{
    printf("Hello world!\n");

    int nr=5;
    while(nr != 0){
        puts("Sunt un program excelent.");
        nr--;
    }
    return 0;
}
