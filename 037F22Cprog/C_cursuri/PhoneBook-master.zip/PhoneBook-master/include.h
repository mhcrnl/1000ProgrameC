#include <clocale>
#include <fstream>
#include <conio.h>
#include <stdlib.h>
#include "windows.h"
using namespace std;
