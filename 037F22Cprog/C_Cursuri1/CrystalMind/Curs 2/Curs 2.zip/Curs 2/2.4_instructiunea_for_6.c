/*
  Scrieti un program care afiseaza numerele divizibile cu 7 din intervalul [0,100].
*/

#include <stdio.h>


int main ()
{





}


