/*
Cititi de la tastatura un 3 numere intregi.
Verificati daca acestea reprezinta valorile 1,2,3 (nu conteaza ordinea).
Afisati un mesaj corespunzator.

Hint: 1+2+3 = 1*2*3
*/


#include <stdio.h>

int main()
{   int a;






    return 0;
}

