/*
  Scrieti un program care determina daca un numar introdus de la tastatura este prim.
  Obs: Un numar este prim daca se divide doar cu 1 sau el insusi;
  Pentru eficientizarea programului se cauta divizorii in intervalul [2, n/2].
  Daca nu se gasesc => n este prim

*/

#include <stdio.h>


int main ()
{
    int n, i, prim=0;

    printf ("Introduceti numarul: \t");
    scanf ("%d", &n);


}


