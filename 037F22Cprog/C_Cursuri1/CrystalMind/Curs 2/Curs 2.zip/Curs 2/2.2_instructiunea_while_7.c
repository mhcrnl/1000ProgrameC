/*
Scrieti un program care determina daca un numar este palindrom

Ex. pentru 121 este palindrom; 1234 nu este palindrom

*/


#include <stdio.h>

int main()
{




}

