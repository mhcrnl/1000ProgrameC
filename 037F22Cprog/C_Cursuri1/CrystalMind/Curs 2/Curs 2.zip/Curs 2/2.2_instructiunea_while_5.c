/*
Scrieti un program care calculeaza suma cifrelor unui numar

Ex. pentru 1234 => suma = 1+2+3+4

*/


#include <stdio.h>

int main()
{




}

