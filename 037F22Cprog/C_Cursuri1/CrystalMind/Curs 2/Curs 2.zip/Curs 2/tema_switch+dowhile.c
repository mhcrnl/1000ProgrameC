/*
Folositi instructiunea case pentru a afisa o data calendaristica citita de la tastatura sub forma zi, luna, an (intregi)
sub forma zi/luna/an, unde zi si an vor fi intregi iar luna va fi sub forma de sir de caractere
(Exemplu: Ianuarie, Februarie, etc)

Folositi instructiunea while/ do while pentru a forta utilizatorul sa introduca date corecte (conforme cu diverse cerinte).
Exemplu: o data calendaristica nu poate avea ziua <=0 sau >=32. Similar, luna nu poate fi <=0 sau >=13
*/

#include <stdio.h>


 int main ()
{






}

