/*

Folositi instructiunea while/do while pentru a forta utilizatorul sa introduca date corecte (conforme cu diverse cerinte).
Exemplu: O data calendaristica nu poate avea ziua <=0 sau >=32. Similar, luna nu poate fi <=0 sau >=13


*/


#include <stdio.h>

int main()
{



}

