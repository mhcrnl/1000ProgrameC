/*
Scrieti un program care determina inversul unui numar

Ex. pentru 12345 => 54321

*/


#include <stdio.h>

int main()
{




}

