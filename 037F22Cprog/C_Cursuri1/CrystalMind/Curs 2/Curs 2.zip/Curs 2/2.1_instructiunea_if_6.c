/*
Scrieti un program care sa calculeze valorile functiei matematice:

                x*x-2 , daca x<0
F(x) =          3, daca x=0
                x+2, daca x>0


*/


#include <stdio.h>

int main()
{   int x;






    return 0;
}

