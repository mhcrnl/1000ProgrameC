/*
Cititi de la tastatura un numar intreg.
Verificati daca numarul respectiv este par sau impar.
Afisati un mesaj corespunzator
*/


#include <stdio.h>

int main()
{   int a;






    return 0;
}

