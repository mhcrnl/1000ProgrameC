/*
  Scrieti un program care numara din x in x (x citit de la tastatura) si afiseaza aceste numere din intervalul [0,100].
  Ex. daca x=17 => vor fi afisate valorile: 0, 17, 34, 51, 68, 85

*/

#include <stdio.h>


int main ()
{





}
