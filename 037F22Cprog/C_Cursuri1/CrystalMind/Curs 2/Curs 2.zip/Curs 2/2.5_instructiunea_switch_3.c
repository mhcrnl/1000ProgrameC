/*
Folositi instructiunea switch pentru a afisa o data calendaristica citita de la tastatura
sub forma zi, luna, an (toate numare intregi) in formatul zi/luna/an, unde zi si an vor fi
intregi iar luna va fi sub forma de sir de caractere (Exemplu: Ianuarie, Februarie, etc).

Exemplu: Daca intruduceti de la tastatura numerele 24, 12, 2015; data va fi afisata sub forma 24/Decembrie/2015


*/


#include <stdio.h>


int main ()
{





}

