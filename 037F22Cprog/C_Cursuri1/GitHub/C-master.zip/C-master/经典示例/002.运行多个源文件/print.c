#include "print.h"

void printHello()
{
	printf("hello word!\n");
}