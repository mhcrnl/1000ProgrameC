#include "print.h"

int main(void){
	printHello();
	return 0;
}