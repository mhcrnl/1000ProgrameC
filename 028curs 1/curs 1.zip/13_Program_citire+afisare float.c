// citere + afisarea unei valori reale (float)

#include <stdio.h>

int main()
{
    float y;

    printf("Introduceti valoarea numarului y: ");

    // Cititi si afisati un numar de tip float

    // Scrieti numarul cu 3 zecimale

    // Scrieti numarul in format mantisa-exponent.

    // Ce se intampla daca introduceti de la tastatura un float si il cititi ca pe un int?


    return 0;
}

