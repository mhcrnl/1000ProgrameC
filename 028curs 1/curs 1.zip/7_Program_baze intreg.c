// citere + afisarea unei valori intregi

#include <stdio.h>

int main()
{
    int x;

    printf("Introduceti valoarea numarului x: ");        // afisare mesaj
    scanf ("%d", &x);                                   // citire valoare de la tastatura

    printf("Valoarea introdusa de la tastaura %d", x);  // afisare valoare

    // Afiseaza dublul numarului in baza 10.

    // Afiseaza dublul numarului in baza 8.

    // Afiseaza dublul numarului in baza 16.


    return 0;
}

