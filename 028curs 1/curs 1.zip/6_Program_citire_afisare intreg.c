// gestionare fructe

#include <stdio.h>

int main ()
{
    int mere, pere;

    printf("Introduceti numarul de mere: ");
    scanf ("%d", &mere);

    printf("Introduceti numarul de pere: ");
    scanf ("%d", &pere);

    printf ("Ana are %d mere si %d pere. ", mere, pere);

    return 0;
}
