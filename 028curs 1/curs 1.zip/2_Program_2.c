// cel mai simplu exemplu de program
// directive preprocesor - fisierul header

#include <stdio.h>                                  // directiva PREPROCESSOR

// functia main() fara argumente, returneaza o valoare de tip int

 main()                                          // header functie
{                                                   // inceput corp functie

    printf("Hai sa programam ...");                 // mesaj
    printf("\n");                                   // linie noua
    printf("....in C!!");                           // alt mesaj

    //return 0;                                       // return la sistemul de operare, fara erori

}                                                   // final corp functie

