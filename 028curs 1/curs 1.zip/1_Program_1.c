// cel mai simplu exemplu de program
// directive preprocesor- fisierul header

#include <stdio.h>  // directiva PREPROCESSOR


// functia main() fara argumente, de tip void
void main()                                         // header functie
{                                                   // inceput corp functie

    printf("Primul Program!");                      // mesaj
    printf("\n");                                 // linie noua
    printf("Yeeyyyy!");                             // alt mesaj

    //return 0;

}                                                   // final corp functie

