// afisarea unei valori

#include <stdio.h>

int main()
{
    float x=7, y=6, z=9;

    printf("Numarul x are valoarea %.7f %f", x, y);

    return 0;
}

