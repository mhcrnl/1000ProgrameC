// afisarea unei caracter

#include <stdio.h>

int main()
{
    char c='a';

    printf("Caracterul c este %c", c);

    return 0;
}

