/*
Scrieti un program pentru afisarea codurilor ASCII al urmatoarelor caractere �A�, �a�, �Z�, �z� .
Puteti folosi urmatorul apel al functiei printf: printf("%c = %d ", caracter, caracter).

*/


#include <stdio.h>

int main()
{


    return 0;
}

